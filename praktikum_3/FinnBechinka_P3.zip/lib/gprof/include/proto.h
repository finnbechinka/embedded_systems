/*See LICENSE of license details.*/

#ifndef _PROTO_H
#define _PROTO_H

#define  NO_INSTRUMENT __attribute__ ((no_instrument_function))
#define  PROFILE  __attribute__ ((section(".prof")))

#endif
